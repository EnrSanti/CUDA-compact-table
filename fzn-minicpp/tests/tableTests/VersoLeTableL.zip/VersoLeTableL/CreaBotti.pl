%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SWI -  JANUARY 24, 2025. AD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Type here YOUR working directory

:-    working_directory(_,'C:/Users/adovi/Dropbox/CLPLAB/VersoLeTable/').

%%% Just in case: :- set_prolog_flag(stack_limit, 8_000_000_000).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

crea(N) :-
    starting(Bmax,Bmed,Bsmall,N),
    setof([Bmax,Bmed,Bsmall],good_triple(N,Bmax,Bmed,Bsmall),FROMSTATES),
    steps(FROMSTATES,LIST),
    prettyprint(LIST,N).

starting(Bmax,Bmed,Bsmall,N) :-
    %%% Creo le tre liste di bits di misura opportuna
    N0 is N+1,  N1 is N//2 +2,  N2 is N//2, 
    length(Bmax,N0), length(Bmed,N1), length(Bsmall,N2).

good_triple(N,Bmax,Bmed,Bsmall) :- 
    %%% Ciascuna ha esattamente un uno
    good(Bmax), good(Bmed), good(Bsmall),
    %%% Controllo che la somma faccia N
    nth0(A,Bmax,1), nth0(B,Bmed,1), nth0(C,Bsmall,1), 
    N is A+B+C.

steps([],[]).
steps([[Bmax, Bmed, Bmin]|R],LIST) :-
    setof(J, applicable(J, Bmax, Bmed, Bmin), ACTS),
    tempsteps(ACTS, [Bmax, Bmed, Bmin], NEWS ), 
    steps(R,List2),
    append(NEWS,List2,LIST).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1 -> pour(12,7)
applicable(1, Bmax, Bmed, _Bmin) :-  \+ empty(Bmax), \+ full(Bmed).
%%% 2 -> pour(12,5)
applicable(2, Bmax, _Bmed, Bmin) :- \+ empty(Bmax), \+ full(Bmin).
%%% 3 -> pour(7,12)
applicable(3, Bmax, Bmed, _Bmin) :-  \+ empty(Bmed), \+ full(Bmax).
%%% 4 -> pour(7,5)
applicable(4, _Bmax, Bmed, Bmin) :- \+ empty(Bmed), \+ full(Bmin).
%%% 5 -> pour(5,12)
applicable(5, Bmax, _Bmed, Bmin) :- \+ empty(Bmin), \+ full(Bmax).
%%% 6 -> pour(5,7)
applicable(6, _Bmax, Bmed, Bmin) :- \+ empty(Bmin), \+ full(Bmed).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


tempsteps([], _, []).


tempsteps([J|ACTS], [Bmax, Bmed, Bmin], [ Tupla |NEWS]) :-
    (J=1, pour(Bmax,Bmed, Bnewmax,Bnewmed), Bnewmin=Bmin;
     J=2, pour(Bmax,Bmin, Bnewmax,Bnewmin), Bnewmed=Bmed;
     J=3, pour(Bmed,Bmax, Bnewmed,Bnewmax), Bnewmin=Bmin;
     J=4, pour(Bmed,Bmin, Bnewmed,Bnewmin), Bnewmax=Bmax;
     J=5, pour(Bmin,Bmax, Bnewmin,Bnewmax), Bnewmed=Bmed;
     J=6, pour(Bmin,Bmed, Bnewmin,Bnewmed), Bnewmax=Bmax),
     append([[J], Bmax, Bmed, Bmin, Bnewmax,Bnewmed,Bnewmin],Tupla),
     tempsteps(ACTS,[Bmax, Bmed, Bmin],NEWS).

pour(B1,B2, B1new,B2new) :-
    length(B1,N1),    length(B2,N2),
    length(B1new,N1), length(B2new,N2),
    contains(B1, Amount), contains(B2, Content),
    Space is N2-1 - Content,
    (Amount > Space, !,
      full(B2new),  V is Amount-Space,  set(B1new,V);
      empty(B1new), V is Content+Amount, set(B2new,V)).
    

%%%%%%%
contains(Barrel,0) :-
   empty(Barrel), !.
contains(Barrel,Amount) :-
   nth0(Amount,Barrel,1).
    
%%%%%%%
      
set([1|LIST],0) :-  
  !, zeros(LIST). 
set([0|LIST],V) :-  
  set(1,V,LIST).
%%% AUX.
set(A,A,[1|R]) :-
  !, zeros(R).
set(A,B,[0|R]) :-
  A1 is A+1,
  set(A1,B,R).
        
%%%%% Botte vuota o piena
empty([1|R]) :- zeros(R).
full([1]).
full([0|R]) :- full(R).

%%% Ci deve essere esattamente un  1
good([1|R]) :- zeros(R).
good([0|R]) :- good(R).

%%%%
zeros([]).
zeros([0|R]) :- zeros(R).
   
   
%%%%   
   
prettyprint(LISTA,N) :-  
    tell('out.txt'),
    write('n = '),write(N),write(';'),nl,
    write('makespan = '),N1 is N-1,write(N1),write(';'),nl,
    write('tabella = ['),
    stampalista(LISTA,1),
    seen,told.
stampalista([A],M) :- !,
    write('| '), stampaultimariga(A),
%%% Stampa makespan
    write(' |];'),nl,
    write('righe = '), write(M), write(';'), nl.
stampalista([A | R],M) :-
    write('| '), stampariga(A), nl,
    M1 is M+1,
    stampalista(R,M1).
stampariga([]).
stampariga([A | R]) :-
    write(A), write(', '),
    stampariga(R).
stampaultimariga([A]) :- 
    !, write(A).
stampaultimariga([A|R]) :- 
    write(A), write(', '),
    stampaultimariga(R).   
