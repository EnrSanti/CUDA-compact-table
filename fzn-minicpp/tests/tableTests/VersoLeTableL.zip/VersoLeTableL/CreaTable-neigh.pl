%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SWI -  JANUARY 22, 2025. AD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% ONLY SWAPS VETWEEN NEIGHBORS ALLOWED

%%% Type here YOUR working directory

:-    working_directory(_,'C:/Users/adovi/Dropbox/CLPLAB/VersoLeTable/').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

crea(N, LIST) :-
    starting(PL,N),
    setof(U,(permutation(PL,U)),LEFT),
    steps(LEFT,LIST,N),
    tell('bubble.txt'),
    write(LIST),nl,
    seen,told.


steps([],[],_).
steps([PERM|R],LIST,N) :-
    tempsteps(PERM,List1,N),
    steps(R,List2,N),
    append(List1,List2,LIST).

tempsteps(PERM,LIST,N) :-
    auxtempsteps(1,N,PERM,LIST).
auxtempsteps(N,N,_,[]) :-!.
auxtempsteps(I,N,PERM,[TUPLE|LIST]) :-
     I1 is I+1,
     swap(I,I1,PERM,NEW),
     append(PERM,[I|NEW],TUPLE),
     auxtempsteps(I1,N,PERM,LIST).

starting(PL,N) :-
    length(PL,N),
    increasing(PL,1).

increasing([],_).
increasing([I|R],I) :-
    I1 is I+1,
    increasing(R,I1).

swap(I,J,L1,L2):-
    nth1(I,L1,V1),
    nth1(J,L1,V2),
    aux_swap(V1,V2,L1,L2).

aux_swap(_,_,[],[]).
aux_swap(V1,V2,[V1|R],[V2|S]) :-
     !, aux_swap(V1,V2,R,S).
aux_swap(V1,V2,[V2|R],[V1|R]) :-
     !.
aux_swap(V1,V2,[A|R],[A|S]) :-
     aux_swap(V1,V2,R,S).



