%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SWI -  JANUARY 22, 2025. AD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Type here YOUR working directory

:-    working_directory(_,'C:/Users/adovi/Dropbox/CLPLAB/VersoLeTable/').

%%% Just in case: :- set_prolog_flag(stack_limit, 8_000_000_000).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

crea(N, LIST) :-
    starting(PL,N),
    setof(U,(permutation(PL,U)),LEFT),
    steps(LEFT,LIST,N),
 %   assignnumber(PERMS,1,LIST),
    tell('out.txt'),
    write(LIST),nl,
    seen,told.


assignnumber([],_, []).
assignnumber([[Left,Right]| R],I,U) :-
    I1 is I+1,
    assignnumber(R,I1,S),
    append([Left,[I|Right],S],U).


steps([],[],_).
steps([PERM|R],LIST,N) :-
    tempsteps(PERM,List1,N),
    steps(R,List2,N),
    append(List1,List2,LIST).

tempsteps(PERM,LIST,N) :-
    auxtempsteps(1,2,PERM,LIST,N,1).
auxtempsteps(N,_,_,[],N,_) :-!.
auxtempsteps(I,J,PERM,[TUPLE|LIST],N,K) :-
     swap(I,J,PERM,NEW),
     append(PERM,[K|NEW],TUPLE),
     plusplus(I,J,N,I1,J1),
     K1 is K+1,
     auxtempsteps(I1,J1,PERM,LIST,N,K1).
plusplus(I,J,N,I,J1) :-
    J < N,!, J1 is J+1.
plusplus(I,N,N,I1,J1) :-
    !, I1 is I+1, J1 is I+2.

starting(PL,N) :-
    length(PL,N),
    increasing(PL,1).

increasing([],_).
increasing([I|R],I) :-
    I1 is I+1,
    increasing(R,I1).

swap(I,J,L1,L2):-
    nth1(I,L1,V1),
    nth1(J,L1,V2),
    aux_swap(V1,V2,L1,L2).

aux_swap(_,_,[],[]).
aux_swap(V1,V2,[V1|R],[V2|S]) :-
     !, aux_swap(V1,V2,R,S).
aux_swap(V1,V2,[V2|R],[V1|R]) :-
     !.
aux_swap(V1,V2,[A|R],[A|S]) :-
     aux_swap(V1,V2,R,S).



